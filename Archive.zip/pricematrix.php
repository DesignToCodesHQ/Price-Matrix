<?php
/*
 *
 * Plugin Name: Price Matrix for Logomyshirts v2
 *
 * Description: Plugin to add pricing matrix, pricing will be calculated based on user, number of items and color
 * Version: 1.1.1 Dev Version
 * Author: Excellarate Team
 * WC requires at least: 2.6.0
 * WC tested up to: 3.4
 */

define('LMS_VERSION', '1.0');
define('LMS_DB_VERSION', '1.0');
define('LMS_REQUIRED_WP_VERSION', '5.5');
define('LMS_PLUGIN', __FILE__);
define('LMS_PLUGIN_BASENAME', plugin_basename(LMS_PLUGIN));
define('LMS_PLUGIN_URL', plugin_dir_url(LMS_PLUGIN));
define('LMS_PLUGIN_NAME', trim(dirname(LMS_PLUGIN_BASENAME), '/'));
define('LMS_PLUGIN_DIR', untrailingslashit(dirname(LMS_PLUGIN)));
define('LMS_MATRIX_TABLE', 'matrixes');
define('LMS_MATRIXCOLS_TABLE', 'matrixes_cols');
define('LMS_MATRIXROWS_TABLE', 'matrixes_rows');
define('LMS_MATRIX_DATA_TABLE', 'matrixes_data');
// define('LMS_PRODUCT_CDN_URL', 'https://lms-sanmar.techgrit.com'); // Harwinder 
define('LMS_PRODUCT_CDN_URL', 'https://logomyhats.com/wp-content/sanmar'); //Rehan
define('LMS_DEFAULT_SCREENPRINTING', '5');
define('LMS_DEFAULT_EMBRIODERY', '6');

require_once LMS_PLUGIN_DIR . '/includes/dbtables.php';
require_once LMS_PLUGIN_DIR . '/includes/admin.php';
require_once LMS_PLUGIN_DIR . '/includes/frontendpricing.php';
require_once LMS_PLUGIN_DIR . '/includes/customer.php';
require_once LMS_PLUGIN_DIR . '/sanmar/getproducts.php';
require_once LMS_PLUGIN_DIR . '/sanmar/pending-counts-ajax/pending-counts.php';
