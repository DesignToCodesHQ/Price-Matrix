<?php 

class LMSPricing {
    public function __construct() {
        $this->addhooks();
        add_action('init', [$this, 'lms_modified_hooks']); // added by Harwinder for cdn functionality
        add_action('wp_enqueue_scripts', [$this, 'lms_sanmar_load_scripts']);
    }
    
    public function lms_modified_hooks() {
        remove_action('woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_thumbnail', 10); // Harwinder
        add_action('woocommerce_before_shop_loop_item_title', [$this, 'lms_add_cdn_url_at_grid_page_for_product'], 10); // Harwinder
        add_filter('woocommerce_cart_item_thumbnail', [$this, 'lms_change_product_cdn_image_at_cart_page'], 10, 3); // Harwinder
        add_filter('rtwpvg_available_variation_gallery', [$this, 'lms_modify_product_image_url_with_cdn'], 100, 3); // Harwinder
        add_filter('wp_get_attachment_image_src',  [$this, 'pn_change_product_image_link'], 1000, 4);
    }
    
    function pn_change_product_image_link($image, $attachment_id, $size, $icon) {
        global $post;
        if (!is_admin() || !isset($post) || !is_object($post) || $post->post_type != "product") {
            return $image;
        }
        
        $_sanmar_cdn_url_front = get_post_meta($post->ID, '_sanmar_cdn_url_front', true);
        $site_url = get_site_url();
        if (strpos($_sanmar_cdn_url_front, 'Images') !== false) {
            $cdn_prefix = 'https://cdn.ssactivewear.com/';
        } elseif (strpos($_sanmar_cdn_url_front, 'imglib') !== false) {
            $cdn_prefix = $site_url . '/wp-content/sanmar';
        } else {
            $cdn_prefix = '';
        }
        if ($_sanmar_cdn_url_front != "") {
            $_sanmar_cdn_url_front = $cdn_prefix . $_sanmar_cdn_url_front;
            $image[0] = $_sanmar_cdn_url_front;
        }
        return $image;
    }
    
    public function lms_sanmar_load_scripts() {
        wp_register_style('lms_frontend_css', LMS_PLUGIN_URL . 'assets/style.css', false);
        wp_enqueue_style('lms_frontend_css');
    }
    
    public function lmsg_testint($class, $attachment_id, $image) {
        return ['teststeteetse'];
    }
    
    public function lms_change_product_cdn_image_at_cart_page($image, $cart_item, $cart_item_key) {
        $product_id = apply_filters('woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key);
        $_load_cdn_images = $this->lms_get_cdn_image($product_id);
        if ($_load_cdn_images !== false) {
            return $_load_cdn_images;
        } else {
            return $image;
        }
    }
    
    public function lms_get_cdn_image($product_id) {
        if ($product_id != '' && $product_id > 0) {
            $_sanmar_cdn_url_front = get_post_meta($product_id, '_sanmar_cdn_url_front', true);
            $lms_parent_product = get_post_meta($product_id, 'lms_parent_product', true);
            $site_url = get_site_url();
            if ($_sanmar_cdn_url_front == '') return false;
            if (strpos($_sanmar_cdn_url_front, "islocal/lms") !== false) {
                $_sanmar_cdn_url_front = str_replace("islocal/lms", $site_url, $_sanmar_cdn_url_front);
            } elseif (strpos($_sanmar_cdn_url_front, "islocal/") !== false) {
                $_sanmar_cdn_url_front = str_replace("islocal", $site_url, $_sanmar_cdn_url_front);
            } else {
                if (strpos($_sanmar_cdn_url_front, 'Images') !== false) {
                    $cdn_prefix = 'https://cdn.ssactivewear.com/';
                } elseif (strpos($_sanmar_cdn_url_front, 'imglib') !== false) {
                    $cdn_prefix = $site_url . '/wp-content/sanmar/thumb';
                } else {
                    $cdn_prefix = '';
                }
                $_sanmar_cdn_url_front = $cdn_prefix . $_sanmar_cdn_url_front;
            }
            return '<img class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail test" src="' . $_sanmar_cdn_url_front . '"/>';
        }
        return false;
    }
    
    public function lms_add_cdn_url_at_grid_page_for_product() {
        global $product;
        $product_id = $product->get_id();
        $_load_cdn_images = $this->lms_get_cdn_image($product_id);
        if ($_load_cdn_images !== false) {
            echo $_load_cdn_images;
        } else {
            echo woocommerce_get_product_thumbnail();
        }
    }
    
    function getprice() {
        return 2;
    }
    
    function get_price_qty_color($price, $qty, $colors, $mid, $type, $is_admin = false) {
        global $wpdb;
        $db_datatable_name = $wpdb->prefix . LMS_MATRIX_DATA_TABLE; // table name
        $db_rowtable_name = $wpdb->prefix . LMS_MATRIXROWS_TABLE; // table name
        $db_coltable_name = $wpdb->prefix . LMS_MATRIXCOLS_TABLE; // table name
        
        if (!isset($mid) or $mid == "" or count($mid) == 0 or $mid[0] == 0) {
            $mid = LMS_DEFAULT_SCREENPRINTING;
        } else {
            $mid = $mid[0];
            $emmid = $emmid[0];
        }
        
        $selectedcol = 0;
        $selectedrow = 0;
        $colors = (is_numeric($colors) && $colors > 6) ? 6 : $colors;
        if (is_numeric($colors) && $mid == 6 && !$is_admin) {
            $colors = 1;
        }
        if (is_numeric($colors) && $mid == 8 && !$is_admin) {
            $colors = 1;
        }
        $sql = "SELECT * from " . $db_coltable_name . " where mid = " . $mid;
        $cols = $wpdb->get_results($sql);
        foreach ($cols as $c) {
            $v = $c->colname;
            $qtysplit = explode("-", $v);
            if ($qty >= $qtysplit[0] and $qty <= $qtysplit[1]) {
                $selectedcol = $c->id;
            }
        }
        
        $sql = "SELECT * from " . $db_rowtable_name . " where mid = " . $mid;
        $rows = $wpdb->get_results($sql);
        foreach ($rows as $c) {
            $v = $c->rowname;
            if ($colors == $v) {
                $selectedrow = $c->id;
            }
        }
        $markupprice = 0;
        $amarkup = "select * from " . $db_rowtable_name . " where mid = " . $mid . " and lower(rowname) LIKE '%apparel%mark%up%';";
        $arows = $wpdb->get_results($amarkup);
        
        if (count($arows) > 0) {
            $adata = $arows[0]->id;
            $amarkdatasql = "SELECT * from " . $db_datatable_name . " where mid = " . $mid . " and mc_id = " . $selectedcol . " and mr_id = " . $adata;
            $amarkdata = $wpdb->get_results($amarkdatasql);
            if (count($amarkdata) == 1) {
                $markuppriceval = str_replace("%", "", $amarkdata[0]->m_val);
                $markupprice = ($price * $markuppriceval) / 100;
            }
        }
        
        $sql = "SELECT * from " . $db_datatable_name . " where mid = " . $mid;
        $sql .= " and mc_id = " . $selectedcol;
        if ($selectedrow > 0) {
            if ($mid == 6 && !$is_admin) {
                $selectedrow = 37; // harwinder hardcoded for type Embroidery Retail
            } else if ($mid == 8 && !$is_admin) {
                $selectedrow = 165;
            }
            $sql .= " and mr_id = " . $selectedrow;
        }
        $data = $wpdb->get_results($sql);
        $newprice = 0;
        if ($mid == 8) {
            $newprice = $data[1]->m_val;
        } else {
            $newprice = $data[0]->m_val;
        }
        
        if ($colors == 0) {
            $newprice = 0;
        }
        if ($type == "markup") {
            return $price + $markupprice;
        } else {
            return $newprice;
        }
    }
    
    function lms_price($price, $product) {
        return (float) $price * $this->getprice();
    }
    
    public function lms_variable_price($price, $variation, $product) {
        return (float) $price * $this->getprice();
    }
    
    public function lms_add_price_multiplier_to_variation_prices_hash($price_hash, $product, $for_display) {
        $price_hash[] = $this->getprice();
        return $price_hash;
    }
    
    public function lms_get_selected_colors_for_each_item($cart_item, $mid) {
        if ($cart_item['lms_attachments_array'] == '' || !isset($cart_item['lms_attachments_array'])) return 0;
        $design_attachments = json_decode($cart_item['lms_attachments_array']);
        $total_colors_price = 0;
        if (!is_object($design_attachments)) return 0;
        foreach ($design_attachments as $side => $data) {
            foreach ($data->logos as $logos) {
                $single_logo_colors = $logos->lms_selected_colors;
                $total_no_of_colors = $single_logo_colors;
                $total_colors_price += $this->get_price_qty_color($price, $cart_item['total_quantity_selected_for_item'], $total_no_of_colors, $mid, 'colors');
            }
        }
        return $total_colors_price;
    }
    
    public function lms_price_cart($cart) {
        if (is_admin() && !defined('DOING_AJAX')) return;
        global $wpdb;
        $total_all_items = [];
        foreach ($cart->get_cart() as $cart_item_key => $cart_item) {
            $cart_id = $cart_item['lms_cart_id'];
            $mid = isset($cart_item['lms_user_selected_printing']) ? $cart_item['lms_user_selected_printing'] : 0;
            $total_colors_price = $this->lms_get_selected_colors_for_each_item($cart_item, $mid);
            $product = $cart_item['data'];
            $lms_parent_product = $product->get_meta('lms_parent_product');
            if (trim($lms_parent_product) != '') { continue; }
            $price = $product->get_price();
            $nocolor = 0;
            $updateprice = $this->get_price_qty_color($price, $cart_item['total_quantity_selected_for_item'], $nocolor, $mid, 'markup');
            $updateprice += $total_colors_price;
            $lms_already_setup = (isset($cart_item['lms_already_setup']) && $cart_item['lms_already_setup'] != '') ? floatval($cart_item['lms_already_setup']) : false;
            if (!$lms_already_setup) {
                $cart_item['data']->set_price($updateprice);
                global $woocommerce;
                $woocommerce->cart->cart_contents[$cart_item_key]['lms_already_setup'] = true;
                $woocommerce->cart->set_session();
            } else {
                global $woocommerce;
                $itesm_before_redirect = $woocommerce->cart->cart_contents[$cart_item_key]['itesm_before_redirect'];
            }
        }
        foreach ($cart->get_cart() as $cart_item_key => $cart_item) {
            echo $cart_item['remove_this'];
            $remove_this = (isset($cart_item['remove_this']) && $cart_item['remove_this'] != '') ? floatval($cart_item['remove_this']) : 0;
            $lms_group_price = (isset($cart_item['lms_group_price']) && $cart_item['lms_group_price'] != '') ? floatval($cart_item['lms_group_price']) : 0;
            if ($lms_group_price > 0) {
                $cart_item['data']->set_price($lms_group_price);
            } else {
                global $woocommerce;
                if (isset($woocommerce->cart->cart_contents[$cart_item_key]['itesm_before_redirect']) && $woocommerce->cart->cart_contents[$cart_item_key]['itesm_before_redirect'] != '' && isset($woocommerce->cart->cart_contents[$cart_item_key]['lms_newly_added_items'])) {
                    $itesm_before_redirect = $woocommerce->cart->cart_contents[$cart_item_key]['itesm_before_redirect'];
                    $cart_item['data']->set_price($itesm_before_redirect);
                }
            }
            if ($remove_this) {
                WC()->cart->remove_cart_item($cart_item_key);
            }
        }
    }
    
    function addhooks() {
        add_action('woocommerce_before_calculate_totals', array($this, 'lms_price_cart'), 9999);
    }

    public function lmsCheckIfContainsDomainName($string) {
        $pattern = '/(http[s]?\:\/\/)?(?!\-)(?:[a-zA-Z\d\-]{0,62}[a-zA-Z\d]\.){1,126}(?!\d+)[a-zA-Z\d]{1,63}/';
        return preg_match($pattern, $string);
    }

    public function lms_modify_product_image_url_with_cdn($available_variation, $variation, $product_id) {
        $all_variations_images = [];
        $variation_id = absint($variation->get_id());
        if (isset($_GET["lmsupdate"])) {
            $lms_sanmar_cdn_urls = get_post_meta($variation_id, 'lms_sanmar_cdn_urls', true);
            $valid_image_urls = array();
            if (!empty($lms_sanmar_cdn_urls) && is_array($lms_sanmar_cdn_urls)) {
                foreach ($lms_sanmar_cdn_urls as $image_url) {
                    if (!empty($image_url) && is_valid_image($image_url)) {
                        $valid_image_urls[] = $image_url;
                    }
                }
            }
        }
        $lms_sanmar_cdn_urls = get_post_meta($variation_id, 'lms_sanmar_cdn_urls', true);
        
        if (!is_array($lms_sanmar_cdn_urls)) {
            $final_thin = unserialize($lms_sanmar_cdn_urls);
            if (is_array($final_thin)) {
                $lms_sanmar_cdn_urls = $final_thin;
            }
        }
        if (!is_array($lms_sanmar_cdn_urls) || count($lms_sanmar_cdn_urls) < 1) return $available_variation;

        foreach ($lms_sanmar_cdn_urls as $keys => $single_cdn_url) {
            if ($single_cdn_url == '') continue;
            if (strpos($single_cdn_url, "islocal/lms") !== false) {
                $single_cdn_url = str_replace("islocal/lms", get_site_url(), $single_cdn_url);
            } elseif (strpos($single_cdn_url, "islocal/") !== false) {
                $single_cdn_url = str_replace("islocal", get_site_url(), $single_cdn_url);
            } else {
                if (strpos($single_cdn_url, 'Images') !== false) {
                    $cdn_prefix = 'https://cdn.ssactivewear.com/';
                } elseif (strpos($single_cdn_url, 'imglib') !== false) {
                    $cdn_prefix = get_site_url() . '/wp-content/sanmar';
                } else {
                    $cdn_prefix = '';
                }
                $single_cdn_url = $cdn_prefix . $single_cdn_url;
                if ($single_cdn_url == "") continue;
            }
            $classes = '';
            $lms_parent_product = get_post_meta($product_id, 'lms_parent_product', true);
            if ($keys == 'another_side' && $lms_parent_product == '') {
                $classes = 'lms-flip-side12';
            }
            $props = array(
                'image_id' => '',
                'title' => '',
                'caption' => '',
                'url' => $single_cdn_url,
                'alt' => $classes,
                'full_src' => $single_cdn_url,
                'full_src_w' => '',
                'full_src_h' => '',
                'full_class' => '',
                'gallery_thumbnail_src' => $single_cdn_url,
                'gallery_thumbnail_src_w' => '',
                'gallery_thumbnail_src_h' => '',
                'gallery_thumbnail_class' => '',
                'archive_src' => '',
                'archive_src_w' => '',
                'archive_src_h' => '',
                'archive_class' => '',
                'src' =>  $single_cdn_url,
                'class' => '',
                'src_w' => '',
                'src_h' => '',
                'srcset' => $single_cdn_url,
                'sizes' => '',
                'extra_params' => ''
            );
            $all_variations_images[] = $props;
        }
        $available_variation['variation_gallery_images'] = $all_variations_images;
        return $available_variation;
    }
}

new LMSPricing();

function is_valid_image($url) {
    $url = get_site_url() . '/wp-content/sanmar' . $url;
    return @getimagesize($url);
}
?>
