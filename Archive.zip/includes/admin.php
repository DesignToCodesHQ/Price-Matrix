<?php 
require 'vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\Spreadsheet;

Class LMSAdmin{
	public function __construct() {
		$this->addhooks ();
	}
		
	function LMS_menupages(){
		
		/* add_menu_page('My Page Title', 'My Menu Title', 'manage_options', 'my-menu', 'my_menu_output' );
		add_submenu_page('my-menu', 'Submenu Page Title', 'Whatever You Want', 'manage_options', 'my-menu' );
		add_submenu_page('my-menu', 'Submenu Page Title2', 'Whatever You Want2', 'manage_options', 'my-menu2' );
		 */
		add_menu_page(  'Pricing Matrix',
				'Pricing Matrix',
				'manage_options',
				'pricingmatrixlist',
				array($this, 'pricingmatrix_list') ,
				null,
				10);
		add_submenu_page('pricingmatrixlist', 
				'Upload Excel',
				'Upload Excel', 
				'manage_options', 
				'pricingmatrix-excel',
				array($this, 'pricingmatrix_upload')
				);
		
	}
	
	
	
	public function ajax_get_matrix_date(){
		ob_start();
		global $wpdb;
		$data = $_POST;
		$mid = $data['mid'];
		$db_table_name = $wpdb->prefix . LMS_MATRIX_DATA_TABLE; // table name
		$db_rowtable_name = $wpdb->prefix . LMS_MATRIXROWS_TABLE; // table name
		$db_coltable_name = $wpdb->prefix . LMS_MATRIXCOLS_TABLE; // table name
		$data = [];
		
		$headings = "SELECT * from $db_coltable_name where mid = $mid";
		$matrixcols = $wpdb->get_results($headings);
		
		$rowquery = "SELECT * from $db_rowtable_name where mid = $mid";
		$matrixrows = $wpdb->get_results($rowquery);
		
		foreach($matrixrows as $c){
			$sql = "SELECT * from ".$db_table_name." as d";
			$sql .= " Where d.mid = $mid and mr_id = ".$c->id;
			$matrixdata = $wpdb->get_results($sql);
			$data[$c->rowname] = $matrixdata;
		}
		$metaview= include "templates/matrixdisplaydata.php";
		$output = ob_get_clean();
		echo $output;
		die;
	}
	
	public function pricingmatrix_list($args){
		ob_start();
		global $wpdb;
		echo "<pre>";
		print_r($args);
		echo "</pre>";
		$ajax = 0;
		$db_matrix_table_name = $wpdb->prefix.LMS_MATRIX_TABLE;
		$matrixesqry = "SELECT * from $db_matrix_table_name";
		$matrixes= $wpdb->get_results($matrixesqry);
		
		$metaview= include "templates/matrixdata.php";
		$output = ob_get_clean();
		echo $output;
		die;
		
		
	}
	
	private function creatematrix($matrixname){
		//Check if it Exists
		global $wpdb;
		$matrixid = 0;
		$db_table_name = $wpdb->prefix . LMS_MATRIX_TABLE; // table name
		$sql = "SELECT * from ".$db_table_name." where matrix_name = '".$matrixname."'";
		$matrix = $wpdb->get_results($sql);
		if(count($matrix) == 0){
			$data = $wpdb->insert( $db_table_name, array(
			'matrix_name' => $matrixname,
			'created_at' =>date('Y-m-d H:i:s'),
			'created_by' => 1,
			'source' =>"Excel" ),
			array( '%s', '%s', '%d', '%s' ));
			$matrixid = $wpdb->insert_id;
		}else{
			$matrixid = $matrix[0]->id;
		}
		return $matrixid;
	}
	
	private function createcols($mid, $colval){
		global $wpdb;
		$db_table_name = $wpdb->prefix . LMS_MATRIXCOLS_TABLE; // table name
		$sql = "SELECT * from ".$db_table_name." where mid = ".$mid." and colname = '".$colval."'";
		$colid = 0;
		$isinsert = 0;
		$col = $wpdb->get_results($sql);
		
		if(count($col) == 0){
			// Insert
			$data = $wpdb->insert( $db_table_name, array(
			'mid' => $mid,
			'colname' => $colval,
			'created_at' =>date('Y-m-d H:i:s'),
			'created_by' => 1,
			),
			array( '%d', '%s', '%d', '%s' ));
			$colid = $wpdb->last_query;
			$isinsert = 1;
		}else{
			$colid= $col[0]->id;
		}
		$return = [$isinsert, $colid];
		return $return;
	}
	
	private function createrows($mid, $rowval){
		global $wpdb;
		$db_table_name = $wpdb->prefix . LMS_MATRIXROWS_TABLE; // table name
		$sql = "SELECT * from ".$db_table_name." where mid = ".$mid." and rowname = '".$rowval."'";
		
		$rowid = 0;
		$row = $wpdb->get_results($sql);
		
		if(count($row) == 0){
			$data = $wpdb->insert( $db_table_name, array(
			'mid' => $mid,
			'rowname' => $rowval,
			'created_at' =>date('Y-m-d H:i:s'),
			'created_by' => 1,
			),
			array( '%d', '%s', '%d', '%s' ));
			$rowid = $wpdb->insert_id;
		}else{
			$rowid= $row[0]->id;
		}
		return $rowid;
	}
	
	private function insertdata($mid, $colid, $rowid, $data){
		global $wpdb;
		$db_table_name = $wpdb->prefix . LMS_MATRIX_DATA_TABLE; // table name
		$sql = "SELECT * from ".$db_table_name." where mid = ".$mid." and mc_id = '".$colid."' and mr_id = '".$rowid."'";
		$row = $wpdb->get_results($sql);
		if(count($row) == 0){
			$data = $wpdb->insert( $db_table_name, array(
					'mid' => $mid,
					'mc_id' => $colid,
					'mr_id' => $rowid,
					'm_val' => $data
					
			),
					array( '%d', '%d', '%d', '%s' ));
		}else{
			$qry = "UPDATE ".$db_table_name." SET m_val = '".$data."' WHERE mid = ".$mid." AND mc_id = ".$colid." AND mr_id = ".$rowid;
			$wpdb->query($wpdb->prepare($qry));
		}
		
		//echo $wpdb->last_query."<br/>";
	}
	
	
	
	public function pricingmatrix_upload(){
		ob_start();
		$reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
	
		if(isset($_POST)) {
			
			if ( !empty( $_FILES['file']['name'] ) ) {
				$pathinfo = pathinfo( $_FILES['file']['name'] );
				if ( ( $pathinfo['extension'] == 'xlsx' || $pathinfo['extension'] == 'xls' ) && $_FILES['file']['size'] > 0 ) {
					$file = $_FILES['file']['tmp_name']; 
					$spreadsheet = $reader->load($file);
					$sheetCount = $spreadsheet->getSheetCount();
					
					for ($i = 0; $i < $sheetCount; $i++) {
						$sheet = $spreadsheet->getSheet($i);
						$sheetname = $spreadsheet->getSheetNames()[$i];
						$mid = $this->creatematrix($sheetname);
						$sheetData = $sheet->toArray(null, true, true, true);
						$z=1;
						for($j = 1; $j<=count($sheetData); $j++){
							//Insert Columns
								foreach($sheetData[$j] as $k => $v){
								 	if($k != 'A'){
										$cold = $sheetData[$z][$k];
										$rowd = $sheetData[$j]['A'];
										
										$colid = $this->createcols($mid, $cold);
										if($colid[0] == 0){
											$rowid = $this->createrows($mid, $rowd);
											$this->insertdata($mid, $colid[1], $rowid, $v);
										}
									}
								} 
								
						}
						$z++;
					}
				} else {
					$erroe_msg = '';
					$erroe_msg = "Please Select Valid Excel File";
				}
			} 
			
			
			
		}
		ob_start();
		$metaview= include "templates/uploadprices.php";
		$output = ob_get_clean();
		echo $output;
		return false;
	}
	
	public function LMS_mime_types($mimes ){
		return array_merge($mimes, array (
				'xls' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
				'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
				'csv' => 'text/csv'
		));
	}
	
	public function ajax_update_matrix_date(){
		$return  = "1";
		
		if(isset($_POST)) {
			$data = $_POST;
			global $wpdb;
			$db_table_name = $wpdb->prefix . LMS_MATRIX_DATA_TABLE; // table name
			$qry = "UPDATE ".$db_table_name." SET m_val = '".$data['newv']."' WHERE mid = ".$data['mid']." AND mc_id = ".$data['mcid'] ." AND mr_id = ".$data['mrid'];
			$wpdb->query($wpdb->prepare($qry));
		}
		return $return;
	}
	
	public function addhooks(){
		add_action('admin_menu', array($this, 'LMS_menupages'));
		add_filter( 'mime_types', array($this, 'LMS_mime_types' ));
		
		add_action( 'wp_ajax_ajax_update_matrix_date', array ($this,'ajax_update_matrix_date' ));
		add_action( 'wp_ajax_nopriv_ajax_update_matrix_date', array ($this,'ajax_update_matrix_date' ));
		
		add_action( 'wp_ajax_ajax_get_matrix_date', array ($this,'ajax_get_matrix_date' ));
		add_action( 'wp_ajax_nopriv_get_update_matrix_date', array ($this,'ajax_get_matrix_date' ));
		
		add_action( 'wp_ajax_ajax_get_matrixes', array ($this,'pricingmatrix_list' ));
		add_action( 'wp_ajax_nopriv_get_update_matrixes', array ($this,'pricingmatrix_list' ));
		
	}
}
	
	new LMSAdmin();
?>