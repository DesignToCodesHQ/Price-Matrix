<table style="width:100%;">
	<tr>
		<th>@</th>
		<?php foreach($matrixcols as $mc){
			echo '<th>'.$mc->colname.'</th>';
		}?>
	</tr>
	
		<?php 
		$i = 1;
		foreach($data as $mk => $md){
			echo "<tr>";
			echo "<td>".$mk."</td>";
			foreach($md as $m){
				echo '<td><input rid="'.$m->mr_id.'" cid="'.$m->mc_id.'" mid="'.$m->mid.'" class="pricetxt" type="text" value="'.$m->m_val.'"/> </td>';
			}
			$i++;
			echo "</tr>";
		}?>
	
</table>