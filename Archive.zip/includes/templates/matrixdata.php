<script>

		function lmsUpdateCalText(elem){
			var selectedVal = jQuery(elem).val();
			jQuery('.wrap .calc').hide();
			if(selectedVal == 1 || selectedVal == 2 || selectedVal == 5){
				jQuery('.wrap .calc.calc-screen-print').show();
			}else{
				jQuery('.wrap .calc.calc-emb-print').show();
			}
		}
		</script>
		<style>
	th, td{
		border:1px solid #ccc;
		padding:4px;
	}
	th{
		background-color:#ccc;
	}
	.pricetxt{
		width:90px;
	}
</style>
<div class="wrap">
		<h2>List of Matrix data</h2>
		<div>
			<select class="updatematrixdata" onchange="lmsUpdateCalText(this)">
				<?php foreach($matrixes as $m){
					echo "<option value='".$m->id."'>".$m->matrix_name."</option>";
				}?>
			</select>
			<span class="calc calc-screen-print">[{Product price from Sanmar * markup % (as per product quantity selected)} + Price for no of color selected]</span>
			<span class="calc calc-emb-print">[{(Product price from Sanmar * markup % (as per product quantity selected)} + Price as per row 1-4000]</p>
		</div>
		<div class="matrixdatadisplay"></div>
	</div>
	<script>
	(function($) {
		lmsUpdateCalText(jQuery(".updatematrixdata"));
		function loadmdata(mid){
			$(".matrixdatadisplay").html("Loading Data....");
			var datareq = {'mid': mid  };
			var aUrl = "<?php echo admin_url('admin-ajax.php?action=ajax_get_matrix_date');?>"
			$.ajax({
				async : true,
				data : datareq,
				dataType : "html",
				url : aUrl,
				type : "POST",
				success : function(data) {
					$(".matrixdatadisplay").html(data);
				}
			});
		}

		var selval = $(".updatematrixdata").find(":selected").val();
		loadmdata(selval);
		
		$("body").on("change", ".updatematrixdata", function(e){
			
			var selval = $(this).find(":selected").val();
			loadmdata(selval);
		});
		
		$("body").on("change", ".pricetxt", function(e){
			var mrid = $(this).attr("rid");
			var mcid = $(this).attr("cid");
			var mid = $(this).attr("mid");
			var newv = $(this).val();
			var aUrl = "<?php echo admin_url('admin-ajax.php?action=ajax_update_matrix_date');?>"

			var datareq = {'mrid': mrid, 'mcid': mcid, 'mid': mid, 'newv':newv  };
			
			$.ajax({
				async : true,
				data : datareq,
				dataType : "json",
				url : aUrl,
				type : "POST",
				success : function(data) {
					
				}
			});
		});
	})( jQuery );
	</script>
