<div class="wrap">
		<h2>Upload Excel to Pricing Matrix</h2>
		
		<a href="<?php echo LMS_PLUGIN_URL;?>/samplepricingmatrix.xlsx" target ="_blank">Download Sample Excel Sheet for Pricing Matrix</a>
		<form action="#" method="post" enctype="multipart/form-data">
			<label for="upload_excel">
	        <input type="file" name="file" id="upload_file">
	        <br />Upload an excel
	    	</label>
			<input type="submit"/>
		</form>
	</div>
	

<script>
    jQuery(document).ready(function($){
    	  if( jQuery( '#upload_file' ).val().length == 0 ) {
    		    jQuery( '#excelsucess' ).html( 'Please select file' );      
    		    return false;
    		  }
	});
    </script>
	