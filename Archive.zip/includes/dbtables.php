<?php
class LMSTables {
	public function __construct() {
		$this->addhooks ();
	}
	function creatematrix() {
		global $wpdb;
		$db_table_name = $wpdb->prefix . LMS_MATRIX_TABLE; // table name
		$charset_collate = $wpdb->get_charset_collate ();
		$db_version = '0.1';
		if ($wpdb->get_var ( "show tables like '$db_table_name'" ) != $db_table_name) {
			$sql = "CREATE TABLE $db_table_name (
			id int(11) NOT NULL auto_increment,
			matrix_name varchar(50) NOT NULL,
			created_at datetime NOT NULL DEFAULT current_timestamp(),
			created_by bigint(20) UNSIGNED NOT NULL,
			source varchar(50)  NOT NULL DEFAULT 'manual',
			status tinyint(1) NOT NULL DEFAULT 1,
			PRIMARY KEY (id)
			) $charset_collate;";
			require_once (ABSPATH . 'wp-admin/includes/upgrade.php');
			dbDelta ( $sql );
			add_option ( 'lms_db_version', $db_version );
		}
	}
	function creatematrixcols() {
		global $wpdb;
		$db_table_name = $wpdb->prefix . LMS_MATRIXCOLS_TABLE; // table name
		$charset_collate = $wpdb->get_charset_collate ();
		$db_version = '0.1';
		if ($wpdb->get_var ( "show tables like '$db_table_name'" ) != $db_table_name) {
			$sql = "CREATE TABLE $db_table_name (
			id int(11) NOT NULL auto_increment,
			mid int(11) NOT NULL,
			colname varchar(50) NOT NULL,
			created_at datetime NOT NULL DEFAULT current_timestamp(),
			created_by bigint(20) UNSIGNED NOT NULL,
			PRIMARY KEY (id)
			) $charset_collate;";
			require_once (ABSPATH . 'wp-admin/includes/upgrade.php');
			dbDelta ( $sql );
			add_option ( 'lms_db_version', $db_version );
		}
	}
	function creatematrixrows() {
		global $wpdb;
		$db_table_name = $wpdb->prefix . LMS_MATRIXROWS_TABLE; // table name
		$charset_collate = $wpdb->get_charset_collate ();
		$db_version = '0.1';
		if ($wpdb->get_var ( "show tables like '$db_table_name'" ) != $db_table_name) {
			$sql = "CREATE TABLE $db_table_name (
			id int(11) NOT NULL auto_increment,
			mid int(11) NOT NULL,
			rowname varchar(50) NOT NULL,
			created_at datetime NOT NULL DEFAULT current_timestamp(),
			created_by bigint(20) UNSIGNED NOT NULL,
			PRIMARY KEY (id)
			) $charset_collate;";
			require_once (ABSPATH . 'wp-admin/includes/upgrade.php');
			dbDelta ( $sql );
			add_option ( 'lms_db_version', $db_version );
		}
	}
	function creatematrixdata() {
		global $wpdb;
		$db_table_name = $wpdb->prefix . LMS_MATRIX_DATA_TABLE; // table name
		$charset_collate = $wpdb->get_charset_collate ();
		$db_version = '0.1';
		if ($wpdb->get_var ( "show tables like '$db_table_name'" ) != $db_table_name) {
			$sql = "CREATE TABLE $db_table_name (
			id int(11) NOT NULL auto_increment,
			mid int(11) NOT NULL,
			mc_id int(11) NOT NULL,
			mr_id int(11) NOT NULL,
			m_val varchar(50) NOT NULL,
			PRIMARY KEY (id)
			) $charset_collate;";
			require_once (ABSPATH . 'wp-admin/includes/upgrade.php');
			dbDelta ( $sql );
			add_option ( 'lms_db_version', $db_version );
		}
	}
	function install_lms_tables() {
		$this->creatematrix ();
		$this->creatematrixcols ();
		$this->creatematrixrows ();
		$this->creatematrixdata ();
	}
	function addhooks() {
		add_action ( 'init', array ($this,'install_lms_tables') );
	}
}

new LMSTables();
?>