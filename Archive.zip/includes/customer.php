<?php 
Class LMSCustomer{
	public function __construct() {
		$this->addhooks ();
	}
	public function getscreenprintingoptions(){
		global $wpdb;
		$db_matrix_table_name = $wpdb->prefix.LMS_MATRIX_TABLE;
		$matrixesqry = "SELECT * from $db_matrix_table_name";
		$matrixes= $wpdb->get_results($matrixesqry);
		$arr = [];
		$arr[0] = "Select";
		foreach($matrixes as $m){
			$arr[$m->id] = $m->matrix_name;
		}	
		return $arr;
	}
	public function extra_user_profile_fields($user){
		global $wpdb;
		
		$db_matrix_table_name = $wpdb->prefix.LMS_MATRIX_TABLE;
		$matrixesqry = "SELECT * from $db_matrix_table_name";
		$matrixes= $wpdb->get_results($matrixesqry);
		
		$sprinting= get_user_meta( $user->ID, '_wcfmmp_price_matrix_type' );
		$eprinting= get_user_meta( $user->ID, '_wcfmmp_price_em_matrix_type' );
		
		?>
		<h3><?php _e("Printing Options", "blank"); ?></h3>
		<table class="form-table">
			<tr>
				<th><label for="screenprinting"><?php _e("Screen Printing Option"); ?></label></th>
				<td><select name="screenprinting"   id="screenprinting">
				<option>Select Screen Printing Option</option>
					<?php 
						foreach($matrixes as $m){
							echo "<option value='".$m->id."'";
							echo ($sprinting[0] == $m->id)?' selected ':"";
							echo " >".$m->matrix_name."</option>";
						}	
					?>
					
					</select></td>
			</tr>
			<tr>
				<th><label for="embroideryprinting"><?php _e("Embroidery Option"); ?></label></th>
				<td><select name="embroideryprinting" id="embroideryprinting">
				<option>Select Embroidery Printing  Option</option>
					<?php 
						foreach($matrixes as $m){
							echo "<option  value='".$m->id."'";
							echo ($eprinting[0] == $m->id)?' selected ':"";
							echo " >".$m->matrix_name."</option>";
						}	
					?>
					
					</select></td>
			</tr>
			
		</table>
		<?php
	}
	
	public function save_extra_user_profile_fields($user_id){
		if (! current_user_can ( 'edit_user', $user_id )) {
			return false;
		}
		update_user_meta ( $user_id, 'embroideryprinting', $_POST ['embroideryprinting'] );
		update_user_meta ( $user_id, 'screenprinting', $_POST ['screenprinting'] );
		
	
	}
	
	public function addhooks(){
		add_action ( 'personal_options_update', array($this, 'save_extra_user_profile_fields') );
		add_action ( 'edit_user_profile_update', array($this, 'save_extra_user_profile_fields') );
		add_action ( 'show_user_profile', array($this, 'extra_user_profile_fields') );
		add_action ( 'edit_user_profile', array($this, 'extra_user_profile_fields') );
	}
}
	
	new LMSCustomer();
?>