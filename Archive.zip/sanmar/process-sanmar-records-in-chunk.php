<?php

use MailPoetVendor\Symfony\Component\Validator\Constraints\Length;

class ProcessSanmarRecordsInChunk
{
    private $dimensions = [];
    private $tmptable = "sanmar_tmp_products";

    public function __construct()
    {
        include_once('models/sanmar-tmp-products-excel-row-model.php');
        include_once('process-sanmar-records-synchronization.php');
    }


    private function InitializeSanmar()
    {
        if (count($this->dimensions) > 0) return;

        $uploaddir = wp_upload_dir();

        $uniq_name = substr(sha1(time()), 0, 10);
        $local_file = $uploaddir['basedir'] . '/dimensions.xlsx';

        $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
        $spreadsheet = $reader->load($local_file);
        $sheetCount = $spreadsheet->getSheetCount();
        $prds = [];
        for ($i = 0; $i < $sheetCount; $i++) {
            $sheet = $spreadsheet->getSheet($i);
            $sheetname = $spreadsheet->getSheetNames()[$i];
            $sheetData = $sheet->toArray(null, true, true, true);
            for ($j = 2; $j <= count($sheetData); $j++) {
                $key = $sheetData[$j]['A'] . "-" . $sheetData[$j]['B'];
                $val = $sheetData[$j];
                $this->dimensions[$key] = $val;
            }
        }
    }

    public function ProcessSanmarItemsInBatch($batchSize)
    {
        if (!is_numeric($batchSize)) {
            $batchSize = 20;
        }
        $objSynchronization = new ProcessSanmarRecordsSynchronization();

        try {

            if ($objSynchronization->getRunningStatus()) {
                error_log('ProcessSanmarItemsInBatch already running');
                return false;
            } else {
                $objSynchronization->setRunning();
            }

            // for ($it = 0; $it < $batchSize; $it++) { // comment it , it is useless , Harwinder code
                try {
                    global $wpdb;
                    $db_table_name = $wpdb->prefix . $this->tmptable; // table name
                    // $sql = "SELECT * from " . $db_table_name . " where is_run = 0 and is_process = 0 and is_duplicate = 0 order by id desc Limit 100";

                    $sql = "SELECT * from " . $db_table_name . " where is_run = 0 and is_process = 0 and is_duplicate = 0 order by id desc Limit " .$batchSize;
                    $rec = $wpdb->get_results($sql);

                    if (count($rec) == 0) {return;}

                    foreach ($rec as $r) { // Mayur cleanup this for loop later // keep forloop outside for synchronization issues
                        error_log("Adding product from Sanmar --" . time());

                        // $title = $r->name;
                        $dt = date('Y-m-d H:i:s');
                        $qry = "UPDATE " . $db_table_name . " SET is_process = 1, run_at = '" . $dt . "' WHERE id = " . $r->id;
                        $wpdb->query($qry);

                        // initialize when needed
                        $this->InitializeSanmar();

                        $prd = SanmarTmpProductsExcelRowModel::Deserialize($r->data);

                        $this->CreateWooProductFromSanmarItemFromExcelRow($prd);

                        // $qry = "UPDATE " . $db_table_name . " SET is_run = 1, run_at = '" . $dt . "' WHERE id = " . $r->id;
                        $qry = "DELETE FROM " . $db_table_name . "  WHERE id = " . $r->id;
                        $wpdb->query($qry); //HArwinder commented for testing
                    }
                } catch (Exception $e) {
                    error_log('Error at ProcessSanmarItemsInBatch' . $e);
                }
            // }
        } finally {
            $objSynchronization->setNotRunning();
        }
    }

    private function CreateWooProductFromSanmarItemFromExcelRow(SanmarTmpProductsExcelRowModel $data)
    {
        include(ABSPATH . '/wp-load.php');
        include_once(ABSPATH . "wp-admin" . '/includes/image.php');
        include_once(ABSPATH . "wp-admin" . '/includes/file.php');
        include_once(ABSPATH . "wp-admin" . '/includes/media.php');

        $output = '';
        $productTitleSanatized = sanitize_title($data->PRODUCT_TITLE);
        $prdexists = get_page_by_path($productTitleSanatized, $output, 'product');
        $all_category_name = $data->CATEGORY;
        $all_categories_ids = [];
        $all_categories = explode(";",$all_category_name);
                $sub_category_name = $data->SUBCATEGORY_NAME;
                $all_sub_categories = explode(";",$sub_category_name);
        foreach($all_categories as $category_name_2){
            $category_name = strval($category_name_2);
        $term = get_term_by('name', $category_name, 'product_cat');
        if ( $term ) {
            $cat_id = $term->term_id;
        }else{
            $cat_id_obj = wp_insert_term($category_name, 'product_cat', array(
            ));
            $cat_id = $cat_id_obj['term_id'];
        }
        foreach($all_sub_categories as $sub_category_name){
                    $child_terms = get_terms( array( 'hide_empty' => false,'slug' =>  strtolower($category_name.'-'.$sub_category_name) ,'taxonomy' => 'product_cat', 'parent' => $cat_id ) );
        if ( is_array($child_terms) && count($child_terms) > 0 ) {
            $first_terms = current($child_terms);
            $sub_cat_id = $first_terms->term_id;
            $cat_id_obj = wp_update_term($sub_cat_id, 'product_cat',  array(
                'parent' => $cat_id // must be the ID, not name
            ));
        }else{
            $cat_id_obj = wp_insert_term($sub_category_name, 'product_cat',  array(
                'parent' => $cat_id,
                'slug' => $category_name.'-'.$sub_category_name
            ));
            if(!is_wp_error($cat_id_obj)){
            $sub_cat_id = $cat_id_obj['term_id'];
            }
        }
        $all_categories_ids[] = $sub_cat_id;
    }

    $all_categories_ids[] = $cat_id;
}
        $att = [];
        $att['color'] = [];
        $att['size'] = [];
        $ilop = 0;

        if ($ilop == 0) {
            $defaultprdatt['size'] =  $data->SIZE; // $size;
            $defaultprdatt['color'] =  $data->COLOR_NAME;// $data->CATALOG_COLOR; //$color; // harwinder Code
        }
        $ilop++;
        // if (!in_array($data->CATALOG_COLOR, $att['color'])) {
        //     array_push($att['color'], $data->CATALOG_COLOR);
        // }
        if (!in_array($data->COLOR_NAME, $att['color'])) { // harwinder code
            array_push($att['color'], $data->COLOR_NAME);
        }
        if (!in_array($data->SIZE, $att['size'])) {
            array_push($att['size'], $data->SIZE);
        }


        if (is_object($prdexists)) {
            $product_id = $prdexists->ID;
            $product = new WC_Product_Variable($product_id);
            foreach($all_categories_ids as $single_cat_id){
                wp_set_object_terms($product_id, $single_cat_id, 'product_cat', true);
                wp_set_object_terms($product_id, $single_cat_id, 'product_cat', true);
            }
        } else {
            $thumbnailid = $this->uploadsanmarimage($data->THUMBNAIL_IMAGE);
            $author = '1';
            $price = 20;
            $stock = 20;
            $length = $this->dimensions[$data->STYLE . '-' . $data->SIZE]['E'];
            $width = $this->dimensions[$data->STYLE . '-' . $data->SIZE]['F'];
            $height = $this->dimensions[$data->STYLE . '-' . $data->SIZE]['G'];
            $post_data = array(
                'post_author' => $author,
                'post_name' => $productTitleSanatized,
                'post_title' => $data->PRODUCT_TITLE,
                'post_content' => $data->PRODUCT_DESCRIPTION,
                'post_excerpt' => $data->PRODUCT_DESCRIPTION,
                'post_status' => 'publish',
                'ping_status' => 'closed',
                'post_type' => 'product',
                'guid' => home_url('/product/' . $productTitleSanatized . '/'),
                '_thumbnail_id' => $thumbnailid
            );
            // Creating the product (post data)
            $product_id = wp_insert_post($post_data);
            set_post_thumbnail($product_id, $thumbnailid);
            foreach($all_categories_ids as $single_cat_id){
                wp_set_object_terms($product_id, $single_cat_id, 'product_cat', true);
                wp_set_object_terms($product_id, $single_cat_id, 'product_cat', true);
            }
                    $product = new WC_Product_Variable($product_id);
            $product->set_sku($data->UNIQUE_KEY);
            $product->set_backorders('yes');
            $product->set_stock_quantity($stock); // Set a minimal stock quantity
            $product->set_manage_stock(true);
            $product->set_stock_status('instock');
            $product->set_weight($data->PIECE_WEIGHT);
            $product->set_length($length);
            $product->set_width($width);
            $product->set_height($height);
            $product->validate_props();
        }

        $product_attributes = array();
        foreach ($att as $key => $terms) {
            $taxonomy = wc_attribute_taxonomy_name($key); // The taxonomy slug
            $attr_label = wc_sanitize_taxonomy_name(ucfirst($key)); // attribute label name
            $attr_name = (wc_sanitize_taxonomy_name($key)); // attribute slug
            if (!taxonomy_exists($taxonomy))
                $this->save_product_attribute_from_name($attr_name, $attr_label);
            $product_attributes[$taxonomy] = array(
                'name' => $taxonomy,
                'value' => '',
                'position' => '',
                'is_visible' => 1,
                'is_variation' => 1,
                'is_taxonomy' => 1
            );

            if(is_array($terms) && !empty($terms) && count($terms) > 0){
                foreach ($terms as $value) {
                    $term_name = trim(ucfirst($value));
                    if($term_name == "")continue;
                    $term_slug = sanitize_title($value);
                    $exit_terms = term_exists($value, $taxonomy);
                    if (!$exit_terms) {
                        $term_data = wp_insert_term($term_name, $taxonomy, array(
                            'slug' => $term_slug
                        )); // Create the term
                        update_term_meta($term_data['term_id'], 'attr_label', strtoupper($term_name));
                        update_term_meta($term_data['term_id'], 'lms_swatch_url', $data->COLOR_SQUARE_IMAGE);
                    }else{

                        update_term_meta($exit_terms['term_id'], 'lms_swatch_url', $data->COLOR_SQUARE_IMAGE);
                    }
                    wp_set_post_terms($product_id, $term_name, $taxonomy, true);
                }
             }
        }
        update_post_meta($product_id, '_product_attributes', $product_attributes);
        update_post_meta($product_id, 'uploaded_from', "sanmarprds");
        update_post_meta($product_id, '_is_customizable', 1);
        $product->save();

        /* Design & Buy */
        $this->configurednb($product_id);

        $varexists = wc_get_product_id_by_sku($data->UNIQUE_KEY . "-" . $product_id);
        if ($varexists == 0) {
            $quantity = 500;
            $length = $this->dimensions[$data->STYLE . '-' . $data->SIZE]['E'];
            $width = $this->dimensions[$data->STYLE . '-' . $data->SIZE]['F'];
            $height = $this->dimensions[$data->STYLE . '-' . $data->SIZE]['G'];
            $price = $data->PIECE_PRICE;

            // if (isset($data->THREE_Q_MODEL) && !empty($data->THREE_Q_MODEL)) {
            //     $image1 = $this->uploadsanmarimage($data->THREE_Q_MODEL);
            // } else {
                // $image1 = $this->uploadsanmarimage($data->FRONT_MODEL);
                // $image1_id = $this->uploadsanmarimage($data->FRONT_MODEL_IMAGE_URL); // Harwinder code , changed the name of header which is in new csv , it is cdn url directly
            // }

            // if (isset($data->BACK_MODEL) && !empty($data->BACK_MODEL)) {
            //     $image2 = $this->uploadsanmarimage($data->BACK_MODEL);
            // } else {
            //     // $image2 = $this->uploadsanmarimage($data->FRONT_MODEL);
            //     $image2 = $this->uploadsanmarimage($data->FRONT_MODEL_IMAGE_URL);// Harwinder code , changed the name of header which is in new csv
            // }

            // $image3 = $this->uploadsanmarimage($data->FRONT_FLAT); // Harwinder code -  commenting for now as we have only one image for cdn in sanmar csv
            // $image4 = $this->uploadsanmarimage($data->BACK_FLAT);

            // $brandLogoImage = $this->uploadsanmarimage($data->BRAND_LOGO_IMAGE);
            // echo '<pre>';
            // print_r($data);
            $front_image =  $back_image =  $side_image = '';
            $full_front_image = $data->FRONT_MODEL_IMAGE_URL;
            $full_back_image = $data->BACK_MODEL_IMAGE_URL;
            $full_front_flat_image = $data->FRONT_FLAT_IMAGE_URL;
            $full_back_flat_image = $data->BACK_FLAT_IMAGE_URL;

            if (strpos($full_front_image, 'Images') !== false || strpos($full_front_flat_image, 'Images') !== false) { // S&S side image condition
                $domain_prefix = "https://cdn.ssactivewear.com/";
                if (strpos($full_front_image, '_omf_') !== false) {
                    $temp_side_image_1 = str_replace("_omf_","_oms_" , $full_front_image);
                    $temp_side_image_2 = str_replace("_omf_","_d_" , $full_front_image);
                    $temp_side_image_2 = str_replace("ModelColor","Color" , $temp_side_image_2);

                    $temp_side_image_1_data = exif_read_data($domain_prefix.$temp_side_image_1, 0, true);
                    $temp_side_image_2_data = exif_read_data($domain_prefix.$temp_side_image_2, 0, true);

                    if ($temp_side_image_1_data['COMPUTED']['Height'] !== '' && $temp_side_image_2_data['COMPUTED']['Height'] !== '') {
                        $full_side_image = $temp_side_image_1;
                    }
                    if ($temp_side_image_1_data['COMPUTED']['Height'] !== '' && $temp_side_image_2_data['COMPUTED']['Height'] == '') {
                        $full_side_image = $temp_side_image_1;
                    }
                    if ($temp_side_image_1_data['COMPUTED']['Height'] == '' && $temp_side_image_2_data['COMPUTED']['Height'] !== '') {
                        $full_side_image = $temp_side_image_2;
                    }
                    if ($temp_side_image_1_data['COMPUTED']['Height'] == '' && $temp_side_image_2_data['COMPUTED']['Height'] == '') {
                        $full_side_image = '';
                    }
                } elseif (strpos($full_front_flat_image, '_f_') !== false) {
                    $temp_side_image = str_replace("_f_","_d_" , $full_front_flat_image);
                    $temp_side_image_data = exif_read_data($domain_prefix.$temp_side_image, 0, true);
                    if ($temp_side_image_data['COMPUTED']['Height'] !== '') {
                        $full_side_image = $temp_side_image;
                    } else {
                        $full_side_image = '';
                    }
                } else {
                    $full_side_image = '';
                }
            } else {
                $temp_side_image = str_replace("front","side" , $full_front_image);
                $temp_side_image_data = exif_read_data($temp_side_image, 0, true);
                if ($temp_side_image_data['COMPUTED']['Height'] !== '') {
                    $full_side_image = $temp_side_image;
                } else {
                    $full_side_image = '';
                }
            }
            if($full_back_image == ''){
                $full_back_image = str_replace("front","back" , $full_front_image);
                $full_back_image_data = exif_read_data($full_back_image, 0, true);

                if(isset($full_back_image_data['APP12']) && $full_back_image_data['COMPUTED']['Height'] == '343' && $full_back_image_data['COMPUTED']['Width'] == '300'){
                    $full_back_image = '';
                }
            }
            $full_side_image_data = exif_read_data($full_side_image, 0, true);
            if(isset($full_side_image_data['APP12']) && $full_side_image_data['COMPUTED']['Height'] == '343' && $full_side_image_data['COMPUTED']['Width'] == '300'){
                $full_side_image = '';
            }
            $full_front_image_obj = parse_url($full_front_image);
            $front_image = $full_front_image_obj['path'];
            if($full_back_image != ''){
            $full_back_image_obj = parse_url($full_back_image);
            $back_image = $full_back_image_obj['path'];
            }
            $full_front_flat_image_obj = parse_url($full_front_flat_image);
            $front_flat_image = $full_front_flat_image_obj['path'];
            $full_back_flat_image_obj = parse_url($full_back_flat_image);
            $back_flat_image = $full_back_flat_image_obj['path'];
            if($full_side_image != ''){
            $full_side_image_obj = parse_url($full_side_image);
            $side_image = $full_side_image_obj['path'];
            }
            update_post_meta($product_id, '_sanmar_cdn_url_front', $front_image); // Harwinder Save image url in product meta
            $image_ids = [];
            $variation = new WC_Product_Variation();
            $variation->set_backorders('yes');
            $variation->set_sku($data->UNIQUE_KEY . "-" . $product_id);
            $variation->set_gallery_image_ids($image_ids);
            $variation->set_stock_quantity($quantity);
            $variation->set_weight($data->PIECE_WEIGHT);
            $variation->set_backorders('yes');
            $variation->set_length($length);
            $variation->set_width($width);
            $variation->set_height($height);
            $variation->set_manage_stock(1);
            $variation->set_regular_price($price);
            $variation->set_parent_id($product_id);
            // $variation->set_image_id($image1_id); // commented because we have cdn url now
            $variation->set_attributes(array(
                'pa_size' => sanitize_title($data->SIZE), // -> removed 'pa_' prefix
                'pa_color' => sanitize_title($data->COLOR_NAME)
            ));
            $variation->save();
            $parent_product = wc_get_product($variation->get_parent_id());
            $variation_id = $variation->get_id();
            $imgs = [];
            // $imgs['rtwpvg'] = [];
            // $imgs['rtwpvg'][$variation_id] = [];
            // $imgs['rtwpvg'][$variation_id][0] = $image1_id;
            $lms_sanmar_cdn_urls_array = ["front" => $front_image, "back" => $back_image,  "side" => $side_image,  'another_side' => $side_image,   "front_flat" => $front_flat_image, 'back_flat' => $back_flat_image ];
            // print_r($lms_sanmar_cdn_urls_array);
            // Keep this code for multiple image for a single varations // Harwinder
            // $imgs['rtwpvg'][$variation_id][1] = $image2;
            // $imgs['rtwpvg'][$variation_id][2] = $image3;
            // $imgs['rtwpvg'][$variation_id][3] = $image4;
            // $rtwpvg_ids = array_filter( $imgs['rtwpvg'][$variation_id], 'strlen' );
            // $rtwpvg_ids = (array) array_map('absint',$rtwpvg_ids);
            // $rtwpvg_ids = array_values(array_unique($rtwpvg_ids));
            update_post_meta($variation_id, 'rtwpvg_images', []);
            update_post_meta($variation_id, 'lms_sanmar_cdn_urls', $lms_sanmar_cdn_urls_array);
            update_post_meta($variation_id,  'lms_swatch_img_url' , $data->COLOR_SQUARE_IMAGE);
            $parent_product->sync($variation_id);
        }


        $product_dattributes = [];
        $product_dattributes['pa_color'] = sanitize_title($defaultprdatt['color']);
        $product_dattributes['pa_size'] = sanitize_title($defaultprdatt['size']);

        update_post_meta($product_id, '_default_attributes', $product_dattributes);
    }

    private function uploadsanmarimage($imageurl)
    {

        // include( 'wp-load.php' );
        if(trim($imageurl) == "") return NULL;
        $tmp_file = download_url($imageurl);
        if(is_wp_error($tmp_file)) return NULL; // Error handling  -  Harwinder Singh
        $uniq_name = date('dmY') . '' . (int) microtime(true);
        $pathinfo = pathinfo($imageurl);
        $filename = $uniq_name . '-' . $pathinfo['filename'] . '.' . $pathinfo['extension'];
        $uploaddir = wp_upload_dir();
        $uploadfile = $uploaddir['path'] . '/' . $filename;
        copy($tmp_file, $uploadfile);
        @unlink($tmp_file);
        $wp_filetype = wp_check_filetype(basename($uploadfile), null);
        $attachment = array(
            'post_mime_type' => $wp_filetype['type'],
            'post_title' => $filename,
            'post_content' => '',
            'post_status' => 'inherit',
            'guid' => $uploaddir['url'] . '/' . basename($filename)
        );
        $attach_id = wp_insert_attachment($attachment, $uploadfile);
        $imagenew = get_post($attach_id);
        $fullsizepath = get_attached_file($imagenew->ID);
        $attach_data = wp_generate_attachment_metadata($attach_id, $fullsizepath);
        wp_update_attachment_metadata($attach_id, $attach_data);
        return $attach_id;
    }

    private function configurednb($product_id)
    {
        global $wpdb;
        $productimagefront = "627a5dd10cb07.png"; // $this->uploadfordnb($prdata ['K']);
        $productimageback = "624efb8701477.png"; // $this->uploadfordnb($prdata ['L']);
        $query1data = array(
            'printing_method_id' => '38',
            'product_id' => $product_id
        );
        $query1format = array(
            '%d',
            '%d'
        );
        $result = $wpdb->insert('designnbuy_printing_methods_product', $query1data, $query1format);
        // Insert into designnbuy_product_configarea
        $query2data = array(
            'product_id' => $product_id,
            'side1_height' => 264,
            'side1_width' => 145,
            'side1_x' => 91,
            'side1_y' => 108,
            'side2_height' => 270,
            'side2_width' => 159,
            'side2_x' => 120,
            'side2_y' => 90
        );
        $query2format = array(
            '%d',
            '%d',
            '%d',
            '%d',
            '%d',
            '%d',
            '%d',
            '%d',
            '%d'
        );
        $wpdb->insert('designnbuy_product_configarea', $query2data, $query2format);
        // Insert into designnbuy_product_settings
        $query3data = array(
            'product_id' => $product_id,
            'no_of_sides' => 2,
            'is_pretemplate' => 'no',
            'base_unit' => 'in',
            'name_number' => 1,
            'global_side_label' => 1,
            'is_multicolor' => 0,
            'is_3d' => 0,
            'is_3d_product' => 0,
            'product_type' => 1,
            'is_text' => 1,
            'is_upload_image' => 1,
            'is_shapes' => 1,
            'is_qr_code' => 1,
            'is_background' => 1,
            'is_vdp' => 1,
            'design_template_cat_id' => '1,10,26,27,28,29,30,31,33,34,35,37,38',
            'printing_method_id' => 38,
            'remove_background' => 1,
            'spot_output' => 1,
            'is_design' => 1,
            'is_clipart' => 1
        );
        $query3format = array(
            '%d',
            '%d',
            '%s',
            '%s',
            '%d',
            '%d',
            '%d',
            '%d',
            '%d',
            '%d',
            '%d',
            '%d',
            '%d',
            '%d',
            '%d',
            '%d',
            '%s',
            '%d',
            '%d',
            '%d',
            '%d',
            '%d'
        );
        $wpdb->insert('designnbuy_product_settings', $query3data, $query3format);
        // Insert into designnbuy_product_sidelabels
        $query4_1data = array(
            'product_id' => $product_id,
            'language_id' => 1,
            'lables' => '{"1":"","2":""}'
        );
        $query4_1format = array(
            '%d',
            '%d',
            '%s'
        );
        $wpdb->insert('designnbuy_product_sidelabels', $query4_1data, $query4_1format);
        $query4_2data = array(
            'product_id' => $product_id,
            'language_id' => 2,
            'lables' => '{"1":"","2":""}'
        );
        $query4_2format = array(
            '%d',
            '%d',
            '%s'
        );
        $wpdb->insert('designnbuy_product_sidelabels', $query4_2data, $query4_2format);
        $query4_3data = array(
            'product_id' => $product_id,
            'language_id' => 3,
            'lables' => '{"1":"","2":""}'
        );
        $query4_3format = array(
            '%d',
            '%d',
            '%s'
        );
        $wpdb->insert('designnbuy_product_sidelabels', $query4_3data, $query4_3format);
        // Insert into designnbuy_product_tool_images
        $query4data = array(
            'product_id' => $product_id,
            'side_images' => '{"1":{"product":"' . $productimagefront . '","mask":"","overlay":"","designArea":"0"},"2":{"product":"' . $productimageback . '","mask":"","overlay":"","designArea":"0"}}'
        );
        $query4format = array(
            '%d',
            '%s'
        );
        $wpdb->insert('designnbuy_product_tool_images', $query4data, $query4format);
    }

    private function get_attribute_id_from_name($name)
    {
        global $wpdb;
        $attribute_id = $wpdb->get_col("SELECT attribute_id
				FROM {$wpdb->prefix}woocommerce_attribute_taxonomies
				WHERE attribute_name LIKE '$name'");
        return reset($attribute_id);
    }

    private function save_product_attribute_from_name($name, $label = '', $set = true)
    {
        // if( ! function_exists ('get_attribute_id_from_name') ) return;
        global $wpdb;
        $label = $label == '' ? ucfirst($name) : $label;
        $attribute_id = $this->get_attribute_id_from_name($name);
        if (empty($attribute_id)) {
            $attribute_id = NULL;
        } else {
            $set = false;
        }
        $args = array(
            'attribute_id' => $attribute_id,
            'attribute_name' => $name,
            'attribute_label' => $label,
            'attribute_type' => 'select',
            'attribute_orderby' => 'menu_order',
            'attribute_public' => 0
        );
        if (empty($attribute_id)) {
            $wpdb->insert($wpdb->prefix . "woocommerce_attribute_taxonomies", $args, array('%d', '%s', '%s', '%s', '%s', '%d'));
            set_transient('wc_attribute_taxonomies', false);
        }
        if ($set) {
            $attributes = wc_get_attribute_taxonomies();
            $args['attribute_id'] = $this->get_attribute_id_from_name($name);
            $attributes[] = (object) $args;
            // print_r($attributes);
            set_transient('wc_attribute_taxonomies', $attributes);
        } else {
            return;
        }
    }
}
