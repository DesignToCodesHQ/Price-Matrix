<style>
    th,
    td {
        border: 1px solid #ccc;
        padding: 4px;
    }

    th {
        background-color: #ccc;
    }

    .pricetxt {
        width: 90px;
    }
</style>
<br />
<div class="wrap">
    <h4 class="sanmarItemsPendingCounts-loaded">Sanmar Items are uploaded to Product List</h4>
    <h4 class="sanmarItemsPendingCounts-pending"></h4>
</div>
<script>
    (function($) {
        function loadSanmarItemsPendingCounts() {
            var aUrl = "<?php echo admin_url('admin-ajax.php?action=ajax_sanmar_items_pending_counts'); ?>"
            $.ajax({
                async: true,
                data: {
                    dt: new Date()
                },
                url: aUrl,
                type: "POST",
                success: function(data) {
                    data = data.trim();
                    dataObj = JSON.parse(data);
                    if (dataObj.success) {
                        if (dataObj.result == 0) {
                            $(".sanmarItemsPendingCounts-loaded").show();
                            $(".sanmarItemsPendingCounts-pending").hide();
                        } else {
                            $(".sanmarItemsPendingCounts-loaded").hide();
                            $(".sanmarItemsPendingCounts-pending").show();
                            $(".sanmarItemsPendingCounts-pending").html('Sanmar Items are still loading... ' + dataObj.result + ' records are pending.');
                        }
                    }
                }
            });
        }

        function loadSanmarItemsPendingCounts_run() {
            $(".sanmarItemsPendingCounts-loaded").hide();
            $(".sanmarItemsPendingCounts").html("Loading Data....");
            loadSanmarItemsPendingCounts();
            setInterval(() => {
                loadSanmarItemsPendingCounts();
            }, 5000);
        }

        loadSanmarItemsPendingCounts_run();

    })(jQuery);
</script>