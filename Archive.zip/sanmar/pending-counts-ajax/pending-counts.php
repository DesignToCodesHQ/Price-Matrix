<?php
class SanmarItemPendingCounts
{
    public $tmptable = "sanmar_tmp_products";

    public function __construct()
    {
        $this->addhooks();
    }

    public function addhooks()
    {
        add_action('wp_ajax_ajax_sanmar_items_pending_counts', array($this, 'ajax_sanmar_items_pending_counts'));
        add_action('wp_ajax_nopriv_ajax_sanmar_items_pending_counts', array($this, 'ajax_sanmar_items_pending_counts_no_priv'));

        // add_action( 'wp_ajax_ajax_update_matrix_date', array ($this,'ajax_update_matrix_date' ));
        // add_action( 'wp_ajax_nopriv_ajax_update_matrix_date', array ($this,'ajax_update_matrix_date' ));

        // add_action( 'wp_ajax_ajax_get_matrix_date', array ($this,'ajax_get_matrix_date' ));
        // add_action( 'wp_ajax_nopriv_get_update_matrix_date', array ($this,'ajax_get_matrix_date' ));

        // add_action( 'wp_ajax_ajax_get_matrixes', array ($this,'pricingmatrix_list' ));
        // add_action( 'wp_ajax_nopriv_get_update_matrixes', array ($this,'pricingmatrix_list' ));

    }

    public function ajax_sanmar_items_pending_counts()
    {
        if (!current_user_can('editor') && !current_user_can('administrator')) {
            return 'please login as editor';
        }

        $return  = "0";
        if (isset($_POST)) {
            $data = $_POST;
            global $wpdb;
            $db_table_name = $wpdb->prefix . $this->tmptable;
            $sql = "SELECT count(*) from " . $db_table_name . " where is_run = 0 and is_process = 0 and is_duplicate = 0";
            $return = $wpdb->get_var($sql);
            echo json_encode(array('success' => true, 'result' => $return));
        } else {
            echo '0';
        }
        exit();
        return $return;
    }

    public function ajax_sanmar_items_pending_counts_no_priv()
    {
        return 'please login as administrator';
    }
}

new SanmarItemPendingCounts();
