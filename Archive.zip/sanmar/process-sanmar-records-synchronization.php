<?php

class ProcessSanmarRecordsSynchronization
{
    private $table_lms_cron_schedule_status = 'lms_cron_schedule_status';

    public function __construct()
    {
    }
    public function __destruct()
    {
    }

    private function Initialize()
    {
        $this->Create_Table_lms_cron_schedule_status();
    }

    private function Create_Table_lms_cron_schedule_status()
    {
        global $wpdb;
        $db_table_name = $wpdb->prefix . $this->table_lms_cron_schedule_status;
        $charset_collate = $wpdb->get_charset_collate();
        // $db_version = '0.1';
        if ($wpdb->get_var("show tables like '$db_table_name'") != $db_table_name) {
            $sql = "CREATE TABLE $db_table_name (
                lms_cron_schedule_status_id BIGINT UNSIGNED NOT NULL , 
                lms_cron_schedule_status_name VARCHAR(200) NOT NULL ,
                lms_cron_schedule_status_value VARCHAR(200) NOT NULL , 
                lms_cron_schedule_status_update_date DATE NOT NULL , 
                PRIMARY KEY (lms_cron_schedule_status_id), 
                UNIQUE WP_LMS_CRON_SCHEDULE_STATUS_UX_NAME (lms_cron_schedule_status_name)
                ) $charset_collate;";
            include_once(ABSPATH . 'wp-admin/includes/upgrade.php');
            $tbl = dbDelta($sql);

            $insertSql = "INSERT INTO $db_table_name (`lms_cron_schedule_status_id`, `lms_cron_schedule_status_name`, `lms_cron_schedule_status_value`, `lms_cron_schedule_status_update_date`) 
            VALUES ('1', 'ProcessSanmarItemsEvery15Mins', '0', '2022-12-05')";
            $wpdb->query($insertSql);
        }
        return $db_table_name;
    }

    public function getRunningStatus($configName = 'ProcessSanmarItemsEvery15Mins')
    {
        global $wpdb;
        $this->Initialize();
        $db_table_name = $wpdb->prefix . $this->table_lms_cron_schedule_status;
        $sql = "SELECT lms_cron_schedule_status_value from " . $db_table_name . " where lms_cron_schedule_status_name='" . $configName . "'";
        $r = $wpdb->get_var($sql);
        if ($r->lms_cron_schedule_status_value == 1) {
            return true;
        } else return false;
    }

    public function setRunning($configName = 'ProcessSanmarItemsEvery15Mins')
    {
        global $wpdb;
        $this->Initialize();
        $db_table_name = $wpdb->prefix . $this->table_lms_cron_schedule_status;
        $dt = date('Y-m-d H:i:s');

        $sql = "UPDATE " . $db_table_name . " SET lms_cron_schedule_status_value=1, lms_cron_schedule_status_update_date = %s WHERE lms_cron_schedule_status_name=%s";
        $preparedSql = $wpdb->prepare($sql, $dt, $configName);
        $wpdb->query($preparedSql);
    }

    public function setNotRunning($configName = 'ProcessSanmarItemsEvery15Mins')
    {
        global $wpdb;
        $this->Initialize();
        $db_table_name = $wpdb->prefix . $this->table_lms_cron_schedule_status;
        $dt = date('Y-m-d H:i:s');

        $sql = "UPDATE " . $db_table_name . " SET lms_cron_schedule_status_value=0, lms_cron_schedule_status_update_date = %s WHERE lms_cron_schedule_status_name=%s";
        $preparedSql = $wpdb->prepare($sql, $dt, $configName);
        $wpdb->query($preparedSql);
    }
}
