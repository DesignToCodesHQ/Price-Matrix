<div class="drag-drop">
	<div id="drag-drop-area" style="position: relative;">
		<div class="drag-drop-inside">
			<h2>Upload Sanmar Product Excel</h2>

			<form action="#" method="post" id="uploadexcelfrm" enctype="multipart/form-data">
				<label for="upload_excel">
					<input type="file" name="file" id="upload_file">
					<br />Upload product excel
				</label>
				<input type="submit" id="uploadexcelbtn" />
			</form>
		</div>
	</div>

</div>
<script>
	jQuery(document).ready(function($) {
		if (jQuery('#upload_file').val().length == 0) {
			jQuery('#excelsucess').html('Please select file');
			return false;
		}

	});
	jQuery('body').on("submit", "#uploadexcelfrm", function(e) {
		//e.preventDefault();
		jQuery('#uploadexcelbtn').prop('disabled', true);
	});
</script>