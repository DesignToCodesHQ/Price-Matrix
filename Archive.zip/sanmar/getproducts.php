<?php

class LMSProductfetch
{
    public $dimensions = [];
    public $tmptable = "sanmar_tmp_products";
    public function __construct()
    {
        $this->addhooks();
    }

    private function addhooks()
    {
        add_action('admin_menu', array($this, 'LMS_sanmarpages'));
        add_filter('cron_schedules', array($this, 'ProcessSanmarItemsEvery15Mins'));
        add_action('ProcessSanmarItemsEvery15Mins', array($this, 'ProcessSanmarItemsBackgroundProcess'));
        add_action('init', array($this, 'forTestingPurpose'));

        if (!wp_next_scheduled('ProcessSanmarItemsEvery15Mins')) {
            wp_schedule_event(time(), 'every_fifteen_minutes', 'ProcessSanmarItemsEvery15Mins');
        }
    }
    public function forTestingPurpose(){
        if(isset($_GET['testCSV'])){
            echo 'in test things';
            //$this->ProcessSanmarItemsBackgroundProcess();
            //$this->updateProdImages();
            $this->merge_images();
        }
    }

    public function adjust_coordinates($coordinate, $container_size, $image_size) {
    // Convert coordinates to float
    $coordinate = (float) $coordinate;

    // Calculate the offset
    $offset = ($container_size - $image_size) / 2;

    // Adjust coordinate based on container size and image size
    $adjusted_coordinate = $coordinate + $offset;

    return $adjusted_coordinate;
}

public function saveDataInTempTable($data) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'temp_data';
    $wpdb->insert($table_name, array('data' => json_encode($data)));
}

public function merge_images(){
    $main_image_path = 'https://logomyhats.com/wp-content/sanmar/imglib/mresjpg/2016/f20/CS401_safetyorange_model_front_102016.jpg';
    $merge_image_path = 'https://logomyhats.com/wp-content/uploads/logo_sample.png';
    $output_path = "/var/www/logomyhats.com/public_html/wp-content/uploads/mergeimage.jpg";

    // User input for container size
    $container_width = 645; // Example: User input for container width
    $container_height = 600; // Example: User input for container height

    // User input for merge image width and coordinates
    $merge_image_width = 154; // Example: User input for merge image width
    $merge_position_x = 246.75-115; // Example: User input for merge image X position
    $merge_position_y = 25; // Example: User input for merge image Y position

    // Load main image within the container
    $main_image = new Imagick($main_image_path);
    $main_image->resizeImage($container_width, $container_height, imagick::FILTER_LANCZOS, 1, true);

    // Get dimensions of main image within the container
    $main_width = $main_image->getImageWidth();
    $main_height = $main_image->getImageHeight();

    // Load merge image (logo)
    $merge_image = new Imagick($merge_image_path);

    // Get dimensions of merge image (logo)
    $merge_image->scaleImage($merge_image_width, 0);

    // Calculate position to place the merge image at the user-defined coordinates
    $merge_position_x = min(max($merge_position_x, 0), $main_width - $merge_image->getImageWidth());
    $merge_position_y = min(max($merge_position_y, 0), $main_height - $merge_image->getImageHeight());

    // Composite merge image onto main image
    $main_image->compositeImage($merge_image, Imagick::COMPOSITE_OVER, $merge_position_x, $merge_position_y);

    // Save the result
    $main_image->writeImage($output_path);

    // Clear resources
    $main_image->clear();
    $merge_image->clear();

    echo "Images merged successfully!";

    exit;
}

public function merge_images1(){
    $main_image_path = 'https://logomyhats.com/wp-content/sanmar/imglib/mresjpg/2016/f20/CS401_safetyorange_model_front_102016.jpg';
    $merge_image_path = 'https://logomyhats.com/wp-content/uploads/2023/07/lms_logo.png';
    $output_path = "/var/www/logomyhats.com/public_html/wp-content/uploads/mergeimage.jpg";

    // Get the merge image width from the database
    $merge_width_from_database = 90; // Get the value from your database

    // Specify the width of the merge image
    $merge_width = $merge_width_from_database * 2; // Adjust as needed

    // Load the merge image to get its dimensions
    $merge = new Imagick($merge_image_path);
    $merge_orig_width = $merge->getImageWidth();
    $merge_orig_height = $merge->getImageHeight();

    // Calculate the height of the merge image based on its aspect ratio
    $merge_height = ($merge_width / $merge_orig_width) * $merge_orig_height;

    // Load main image
    $main = new Imagick($main_image_path);

    // Container size in frontend
    $container_width = 645;
    $container_height = 600;

    // Frontend coordinates
    $frontend_x = 559;
    $frontend_y = 627;

    // Calculate the position of the merge image based on frontend coordinates and image dimensions
    $merge_x = $frontend_x + ($container_width / 2) - ($merge_width / 2);
    $merge_y = $frontend_y + ($container_height / 2) - ($merge_height / 2);

    // Resize the merge image
    $merge->scaleImage($merge_width, $merge_height);

    // Composite merge image onto main image
    $main->compositeImage($merge, Imagick::COMPOSITE_OVER, $merge_x, $merge_y);

    // Save the merged image
    $main->writeImage($output_path);

    // Free up memory
    $main->destroy();
    $merge->destroy();

    echo "ok";
    exit;
}


    public function updateProdImages(){
        global $wpdb;

        $query = "
            SELECT PM.post_id
            FROM {$wpdb->prefix}postmeta PM
            WHERE PM.meta_key LIKE 'lms_sanmar_cdn_urls' AND PM.meta_value LIKE 'a:0:{}'
        ";
        $variations = $wpdb->get_results( $query );

        $productIds = [];
        $trash = [];
        foreach( $variations as $var_id ) {
            //$pid = wp_get_post_parent_id( $var_id->post_id );
            
            $parent_id   = wp_get_post_parent_id( $var_id->post_id );
            $parent_post = get_post( $parent_id );      

            if ($parent_post->post_title!= '' &&  $parent_post->post_status !== 'trash' ) {
                // $product = wc_get_product( $parent_id );

                //if ( $product ) {
                    $productIds[$parent_id] = $parent_post->post_title;
                //}
            }else if ($parent_post->post_title!= ''){
                $trash[$parent_id] = $parent_post->post_title;
            }
        }

        echo '<pre>';
        print_r( ($productIds ));
        echo 'Trash<pre>';
        print_r( ($trash ));
        exit;


        $uploaddir = wp_upload_dir();
        $uniq_name = substr(sha1(time()), 0, 10);
        $local_file = $uploaddir['basedir'] . '/sanmar_prod_updated.xlsx';
        $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
        $spreadsheet = $reader->load($local_file);
        $sheetCount = $spreadsheet->getSheetCount();
        $prds = [];
        for ($i = 0; $i < $sheetCount; $i++) {
            $sheet = $spreadsheet->getSheet($i);
            $sheetname = $spreadsheet->getSheetNames()[$i];
            
            $sheetData = $sheet->toArray(null, true, true, true);
            
            for ($j = 2; $j <= count($sheetData); $j++) {
                $post_title = $sheetData[$j]['B'];
                echo "Product Title : ".$post_title."<br>";
                
                $query = $wpdb->prepare( "
                    SELECT ID,post_title,guid
                    FROM {$wpdb->posts}
                    WHERE post_title = %s
                    LIMIT 1
                ", $post_title );
                $post = $wpdb->get_row( $query );
                echo '<pre>';print_r($post);

                echo "Front Model : ".$front_model = $sheetData[$j]['AG']."<br>";
                echo "Back Model : ".$back_model = $sheetData[$j]['AH']."<br>";
                echo "Front Flat : ".$front_flat = $sheetData[$j]['AI']."<br>";
                echo "Back Flat : ".$back_flat = $sheetData[$j]['AJ']."<br>";


                //image path and array process
                $imagePath = array(
                    'front' => str_replace('https://cdnm.sanmar.com','',$sheetData[$j]['AG']),
                    'back' => str_replace('https://cdnm.sanmar.com','',$sheetData[$j]['AG']),
                    'front_flat' => str_replace('https://cdnm.sanmar.com','',$sheetData[$j]['AG']),
                    'back_flat' => str_replace('https://cdnm.sanmar.com','',$sheetData[$j]['AJ']),
                    'side'  => '',
                    'another_side'  => '',
                );

                echo '<br><pre>';print_r(($imagePath))."<br>";

                echo '<br><pre>';print_r(serialize($imagePath));
                exit;
                
                //get product details by title
                

                $val = $sheetData[$j];
                $this->dimensions[$key] = $val;
            }
        }

    }

    public function LMS_sanmarpages()
    {
        add_menu_page('Sanmar Products', 'Sanmar Products', 'read', 'sanmarprds', array(
            $this,
            'LMS_ShowSanmarProductList'
        ), null, 10);
        add_submenu_page('sanmarprds', 'Upload Excel', 'Upload Excel', 'read', 'sanmarprds-excel', array(
            $this,
            'LMS_UploadSanmarProducts'
        ));
    }

    public function LMS_ShowSanmarProductList()
    {
    }


    public function LMS_UploadSanmarProducts()
    {
        include_once('log-critical-error.php');
        try {

            if (!empty($_FILES['file']['name'])) {
                $startime = microtime(true);

                include 'load-sanmar-records-from-file.php';
                $obj = new LoadSanmarRecordsFromFile();
                $obj->LoadFile($_FILES['file']);
                (new LogCriticalErrors())->Log('Loaded file.');

                // include_once('process-sanmar-records-in-chunk.php');
                // (new ProcessSanmarRecordsInChunk())->ProcessSanmarItemsInBatch(100); // Mayur Testing

                $time_elapsed_secs = microtime(true) - $startime;
                $this->debug("Time to execute the command: " . $time_elapsed_secs . " sec");
            }
        } catch (Exception $e) {
            (new LogCriticalErrors())->Log('-' . $e);
            error_log("Internal error : " . $e);
            $this->debug("Internal error : " . $e);
        }

        try {
            ob_start();
            $metaview = include "templates/uploadproducts.php";
            $metaview2 = include "pending-counts-ajax/pending-counts-js.php";
            $output = ob_get_clean();
            echo $output;
        } catch (Exception $e) {
            echo 'Mayur testing ' . $e;
        }
        return false;
    }

    private function debug($d)
    {
        echo "<pre style='border:1px solid rgba(255,0,0,0.5); padding:10px; background-color:rgba(0,0,0,0.13);'>";
        print_r($d);
        echo "</pre>";
    }

    public function ProcessSanmarItemsBackgroundProcess()
    {
        try {
            include_once('process-sanmar-records-in-chunk.php');
            $obj = new ProcessSanmarRecordsInChunk();
            $obj->ProcessSanmarItemsInBatch(70); // Harwinder commented
        } catch (Exception $e) {
            error_log("Internal error ProcessSanmarItemsBackgroundProcess: " . $e);
            $this->debug("Internal error ProcessSanmarItemsBackgroundProcess: " . $e);
        }
    }

    public function ProcessSanmarItemsEvery15Mins($schedules)
    {
        try {
            error_log("ProcessSanmarItemsEvery15Mins v2 Started");
            $schedules['every_fifteen_minutes'] = array(
                'interval'  => 60 * 1,
                'display'   => __('Runs product creation for every 15 Minutes', 'LHS')
            );
            return $schedules;
        } catch (Exception $e) {
            return $schedules;
        }
    }
}
new LMSProductfetch();
