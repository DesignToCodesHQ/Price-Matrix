<?php

class LoadSanmarRecordsFromCSV
{
    public $dimensions = [];
    private $tmptable = "sanmar_tmp_products";

    public function __construct()
    {
        include_once('models/sanmar-tmp-products-excel-row-model.php');
        include_once('log-critical-error.php');
    }

    private function debug($d)
    {
        echo "<pre style='border:1px solid rgba(255,0,0,0.5); padding:10px; background-color:rgba(0,0,0,0.13);'>";
        print_r($d);
        echo "</pre>";
    }


    private function decodeString($str)
    {
        $decodeEnable = true;

        if ($decodeEnable) {
            if (is_numeric($str)) {
                return $str;
            }
            $str = base64_decode($str);
        }

        return $str;
    }

    private function remove_utf8_bom($text)
    {
        $bom = pack('H*','EFBBBF');
        $text = preg_replace("/^$bom/", '', $text);
        return $text;
    }

    private function ConvertToExcelRowModel($header, $line): SanmarTmpProductsExcelRowModel
    {
        $retModel = new SanmarTmpProductsExcelRowModel();
        foreach ($header as $excelColumnId => $excelColumnName) {
            $excelColumnNameCorrected = str_replace("#", "", $excelColumnName);
            $excelColumnNameCorrected = $this->remove_utf8_bom($excelColumnNameCorrected); // added code to fix the character types  - Harwinder code
            $retModel->$excelColumnNameCorrected =  $line[$excelColumnId];
            if (is_string($retModel->$excelColumnNameCorrected)) {
                $retModel->$excelColumnNameCorrected = trim($retModel->$excelColumnNameCorrected);
            }
        }

        $retModel->CATEGORY = $retModel->CATEGORY_NAME;
        $retModel->SUBCATEGORY_NAME = $retModel->SUBCATEGORY_NAME;

        $retModel->UNIQUE_KEY = $this->decodeString($retModel->UNIQUE_KEY);
        $retModel->PIECE_WEIGHT = $this->decodeString($retModel->PIECE_WEIGHT);
        $retModel->PIECE_PRICE = $this->decodeString($retModel->PIECE_PRICE);

        $retModel->PRODUCT_TITLE = html_entity_decode($retModel->PRODUCT_TITLE);

        return $retModel;
    }

    private function CreateSanmarTmpProductsRowByExcelRow(SanmarTmpProductsExcelRowModel $data)
    {
        global $wpdb;
        $key =  $data->PRODUCT_TITLE;
        $sku = $data->UNIQUE_KEY;
        $db_table_name = $wpdb->prefix . $this->tmptable; // table name
        $sql = "SELECT * from " . $db_table_name . " where sku = '" . $sku . "'";
        $rec = $wpdb->get_results($sql);
        // if (count($rec) == 0) {
            $inserttmpprd = $wpdb->insert(
                $db_table_name,
                array(
                    'name'     =>   $this->remove_utf8_bom($key),
                    'data'     =>    json_encode($data),
                    'sku'    =>    $sku

                ),
                // array('%s', '%s', '%s')
            );
        // }
    }

    public function LoadFile($file, $categoriesaccepted)
    {
        $spreadsheet = 0;
        try {
            $file = $file['tmp_name'];
            $spreadsheet = fopen($file, "r");
            $i = 0;
            $header = fgetcsv($spreadsheet);

            while (($line = fgetcsv($spreadsheet)) != FALSE) {
                $excelRowModel = $this->ConvertToExcelRowModel($header, $line);
                // if (in_array($excelRowModel->CATEGORY, $categoriesaccepted)) { make it commented , because we are not sure which category we need to proceed   Harwinder
                    $this->CreateSanmarTmpProductsRowByExcelRow($excelRowModel);
                // }
            }
        } finally {
            if ($spreadsheet != 0) {
                fclose($spreadsheet);
            }
        }

        return false;
    }
}
