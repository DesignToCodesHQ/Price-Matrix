<?php

class SanmarTmpProductsExcelRowModel extends JsonDeserializer
{
    public $UNIQUE_KEY = "";
    public $PRODUCT_TITLE    = "";
    public $PRODUCT_DESCRIPTION    = "";
    public $STYLE = "";
    public $AVAILABLE_SIZES = "";
    public $BRAND_LOGO_IMAGE = "";
    public $THUMBNAIL_IMAGE = "";
    public $COLOR_SWATCH_IMAGE = "";
    public $PRODUCT_IMAGE = "";
    public $SPEC_SHEET = "";
    public $FRONT_FLAT = "";
    public $BACK_FLAT = "";
    public $FRONT_MODEL = "";
    public $BACK_MODEL = "";
    public $SIDE_MODEL = "";
    public $THREE_Q_MODEL = "";
    public $PRICE_TEXT = "";
    public $COLOR_NAME = "";
    public $COLOR_SQUARE_IMAGE = "";
    public $COLOR_PRODUCT_IMAGE = "";
    public $COLOR_PRODUCT_IMAGE_THUMBNAIL = "";
    public $SIZE = "";
    public $PIECE_WEIGHT = "";
    public $PIECE_PRICE = "";
    public $DOZEN_PRICE = "";
    public $CASE_PRICE = "";
    public $PIECE_SALE_PRICE = "";
    public $DOZEN_SALE_PRICE = "";
    public $SALE_START_DATE = "";
    public $SALE_END_DATE = "";
    public $CASE_SIZE = "";
    public $INVENTORY_KEY = "";
    public $SIZE_INDEX = "";
    public $CATALOG_COLOR = "";
    public $PRICE_CODE = "";
    public $PRODUCT_STATUS = "";
    public $TITLE_IMAGE = "";
    public $BRAND_NAME = "";
    public $KEYWORDS = "";
    public $CATEGORY = "";
    public $SUBCATEGORY_NAME = "";
    public $FRONT_MODEL_IMAGE_URL = ""; // harwinder Added for new columns for csv
    public $BACK_MODEL_IMAGE_URL = ""; // harwinder Added for new columns for csv
    public $FRONT_FLAT_IMAGE_URL = ""; // harwinder Added for new columns for csv
    public $BACK_FLAT_IMAGE_URL = ""; // harwinder Added for new columns for csv


    public function ToString(): string
    {
        return "";
    }
}


abstract class JsonDeserializer
{
    /**
     * @param string|array $json
     * @return $this
     */
    public static function Deserialize($json)
    {
        $className = get_called_class();
        $classInstance = new $className();
        if (is_string($json))
            $json = json_decode($json);

        foreach ($json as $key => $value) {
            if (!property_exists($classInstance, $key)) continue;

            $classInstance->{$key} = $value;
        }

        return $classInstance;
    }
    /**
     * @param string $json
     * @return $this[]
     */
    public static function DeserializeArray($json)
    {
        $json = json_decode($json);
        $items = [];
        foreach ($json as $item)
            $items[] = self::Deserialize($item);
        return $items;
    }
}
