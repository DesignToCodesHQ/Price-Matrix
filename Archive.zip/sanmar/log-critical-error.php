<?php
class LogCriticalErrors
{
    public function Log($err_desc)
    {
        global $wpdb;
        $db_table_name = $wpdb->prefix . 'lms_internal_errors';
        $sql = "INSERT $db_table_name (error_desc) values(%s)";
        $preparedSql = $wpdb->prepare($sql, $err_desc);
        $wpdb->query($preparedSql);
    }
}
