<?php

class LoadSanmarRecordsFromExcel
{
    public $dimensions = [];
    private $tmptable = "sanmar_tmp_products";

    public function __construct()
    {
        include_once('models/sanmar-tmp-products-excel-row-model.php');
        include_once('log-critical-error.php');
    }

    private function decodeString($str)
    {
        $decodeEnable = true;

        if ($decodeEnable) {
            if (is_numeric($str)) {
                return $str;
            }
            $str = base64_decode($str);
        }

        return $str;
    }

    private function ConvertToExcelRowModel($header, $data): SanmarTmpProductsExcelRowModel
    {
        $retModel = new SanmarTmpProductsExcelRowModel();

        foreach ($header as $excelColumnId => $excelColumnName) {
            $excelColumnNameCorrected = str_replace("#", "", $excelColumnName);
            $retModel->{$excelColumnNameCorrected} = $data[$excelColumnId];
            if (is_string($retModel->$excelColumnNameCorrected)) {
                $retModel->{$excelColumnNameCorrected} = trim($retModel->$excelColumnNameCorrected);
            }
        }

        $retModel->CATEGORY = $retModel->CATEGORY_NAME;
        $retModel->SUBCATEGORY_NAME = $retModel->SUBCATEGORY_NAME;

        $retModel->UNIQUE_KEY = $this->decodeString($retModel->UNIQUE_KEY);
        $retModel->PIECE_WEIGHT = $this->decodeString($retModel->PIECE_WEIGHT);
        $retModel->PIECE_PRICE = $this->decodeString($retModel->PIECE_PRICE);

        $retModel->PRODUCT_TITLE = html_entity_decode($retModel->PRODUCT_TITLE);

        return $retModel;
    }

    private function CreateSanmarTmpProductsRowByExcelRow(SanmarTmpProductsExcelRowModel $data)
    {   
        global $wpdb;
        $key =  $data->PRODUCT_TITLE;
        $sku = $data->UNIQUE_KEY;
        $db_table_name = $wpdb->prefix . $this->tmptable; // table name
        $sql = "SELECT * from " . $db_table_name . " where sku = '" . $sku . "'";
        $rec = $wpdb->get_results($sql);
        // if (count($rec) == 0) {
            $inserttmpprd = $wpdb->insert(
                $db_table_name,
                array(
                    'name'     =>    $key,
                    'data'     =>    json_encode($data),
                    'sku'    =>    $sku

                ),
                array('%s', '%s', '%s')
            );
        // }
    }

    public function LoadFile($file, $categoriesaccepted)
    {
        $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
        $file = $file['tmp_name'];
        $spreadsheet = $reader->load($file);
        $sheet = $spreadsheet->getSheet(0);
        $sheetData = $sheet->toArray(null, true, true, true);
        for ($rowIt = 2; $rowIt <= count($sheetData); $rowIt++) {
            $excelRowModel = $this->ConvertToExcelRowModel($sheetData[1], $sheetData[$rowIt]);
            // if (in_array($excelRowModel->CATEGORY_NAME, $categoriesaccepted)) {
                // echo 'in if conditionss';
                $this->CreateSanmarTmpProductsRowByExcelRow($excelRowModel);
            // }
        }
        // exit;
        return false;
    }
}
