<?php

class LoadSanmarRecordsFromFile
{
    private $tmptable = "sanmar_tmp_products";

    public function __construct()
    {
        include_once('models/sanmar-tmp-products-excel-row-model.php');
        include_once('log-critical-error.php');
        include_once('load-sanmar-records-from-excel.php');
        include_once('load-sanmar-records-from-csv.php');
    }

    private function debug($d)
    {
        echo "<pre style='border:1px solid rgba(255,0,0,0.5); padding:10px; background-color:rgba(0,0,0,0.13);'>";
        print_r($d);
        echo "</pre>";
    }

    private function CreateSanmarTable()
    {
        global $wpdb;
        $db_table_name = $wpdb->prefix . $this->tmptable;
        $charset_collate = $wpdb->get_charset_collate();
        // $db_version = '0.1';
        if ($wpdb->get_var("show tables like '$db_table_name'") != $db_table_name) {
            $sql = "CREATE TABLE $db_table_name (
    			id int(11) NOT NULL auto_increment,
    			name varchar(50) NOT NULL,
    			created_at datetime NOT NULL DEFAULT current_timestamp(),
    			is_run tinyint(1) NOT NULL DEFAULT 0,
    			is_process tinyint(1) NOT NULL DEFAULT 0,
    			is_duplicate tinyint(1) NOT NULL DEFAULT 0,
    			data text NOT NULL,
    			sku varchar(100) NOT NULL,
    			status_comments text NULL,
    			run_at datetime  NULL DEFAULT '0000-00-00 00:00:00',
    			PRIMARY KEY (id)
    			) $charset_collate;";
            include_once(ABSPATH . 'wp-admin/includes/upgrade.php');
            $tbl = dbDelta($sql);
        }
        return $db_table_name;
    }


    public function LoadFile($file)
    {
        $categoriesaccepted = ['t-shirts', 'polos/knits'];

        try {

            if (!empty($file['name'])) {
                $this->CreateSanmarTable();
                $pathinfo = pathinfo($file['name']);
                if (($pathinfo['extension'] == 'xlsx' ||
                        $pathinfo['extension'] == 'xls') &&
                    $file['size'] > 0
                ) {
                    (new LoadSanmarRecordsFromExcel())->LoadFile($file, $categoriesaccepted);
                } else if (
                    $pathinfo['extension'] == 'csv' &&
                    $file['size'] > 0
                ) {
                    (new LoadSanmarRecordsFromCSV())->LoadFile($file, $categoriesaccepted);
                }
                // $this->ProcessSanmarItemsInBatch(100); // Mayur Testing
                // (new ProcessSanmarRecordsInChunk())->ProcessSanmarItemsInBatch(100); // Mayur Testing
            }
        } catch (Exception $e) {
            error_log("Internal error : " . $e);
            $this->debug("Internal error : " . $e);
        }

        return false;
    }
}
